## Models
Download links for the pre-trained models:
- Low-res model:
  - Architecture: https://drive.google.com/open?id=1IJ4k1TtFpConpkJVsGf37F-WWJ1rmP4Y
  - Weights: https://drive.google.com/open?id=1mFvc20GbzUGyo9xl401BNxGNSLiKEewr
- Fine-tuned model:
  - Architecture: n/a
  - Weights: n/a
- Segmentation model:
  - Weights: n/a

